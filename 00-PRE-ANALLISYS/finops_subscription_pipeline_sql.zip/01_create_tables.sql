-- Replace `your_project.your_dataset` with your project+dataset.
-- Tables:
--   1) subscription_plans
--   2) subscription_plan_costs_daily
--   3) cost_data_standard_1_2  (FOCUS v1.2 column set, but neutral name)

CREATE TABLE IF NOT EXISTS `your_project.your_dataset`.subscription_plans (
  provider STRING NOT NULL OPTIONS(description="REQUIRED. Provider key (canonical). Example: openai, anthropic, adobe, canva."),
  plan_name STRING NOT NULL OPTIONS(description="REQUIRED. Plan identifier/name from catalog. Example: PRO, TEAM."),
  display_name STRING NOT NULL OPTIONS(description="REQUIRED. Human-friendly plan name. Example: ChatGPT Team."),
  subscription_id STRING NOT NULL OPTIONS(description="REQUIRED. Stable internal subscription instance id. Example: SUB-000123."),

  category STRING OPTIONS(description="NULLABLE. Category/grouping. Example: AI, Design, DevTools."),
  billing_period STRING OPTIONS(description="NULLABLE. Catalog billing period. Example: monthly, annual."),
  unit_price_usd NUMERIC OPTIONS(description="NULLABLE. Catalog/list monthly unit price in USD."),
  yearly_price_usd NUMERIC OPTIONS(description="NULLABLE. Catalog/list annual price in USD."),
  yearly_discount_pct NUMERIC OPTIONS(description="NULLABLE. Catalog annual discount percent (if known)."),

  status STRING OPTIONS(description="NULLABLE. Suggested: active, trialing, paused, canceled."),
  owner STRING OPTIONS(description="NULLABLE. Responsible owner (person/team)."),
  department STRING OPTIONS(description="NULLABLE. Department for allocation."),
  cost_center STRING OPTIONS(description="NULLABLE. Cost center for allocation."),
  seats INT64 NOT NULL OPTIONS(description="REQUIRED. Seat count. Default 0."),

  billing_cycle STRING OPTIONS(description="NULLABLE. Actual billing cycle for this instance: monthly/annual."),
  currency STRING OPTIONS(description="NULLABLE. Billing currency. Example: USD."),
  price_per_cycle NUMERIC OPTIONS(description="NULLABLE. Actual billed/contracted amount per cycle."),
  discount_type STRING OPTIONS(description="NULLABLE. percent, fixed, none."),
  discount_value NUMERIC OPTIONS(description="NULLABLE. Discount value for discount_type."),

  start_date DATE OPTIONS(description="NULLABLE. Subscription start date."),
  trial_end_date DATE OPTIONS(description="NULLABLE. Trial end date."),
  end_date DATE OPTIONS(description="NULLABLE. Contract end date (if fixed-term)."),
  renewal_date DATE OPTIONS(description="NULLABLE. Next renewal/charge date."),

  auto_renew BOOL OPTIONS(description="NULLABLE. Auto-renew on/off."),
  status_changed_date DATE OPTIONS(description="NULLABLE. Audit-light: last status change date."),
  cancel_at_period_end BOOL OPTIONS(description="NULLABLE. True if set to cancel at end of current period."),
  cancellation_date DATE OPTIONS(description="NULLABLE. Cancellation effective/requested date (define convention)."),

  payment_method STRING OPTIONS(description="NULLABLE. card, invoice, ach, etc."),
  billing_email STRING OPTIONS(description="NULLABLE. Billing contact email."),
  provider_account_email STRING OPTIONS(description="NULLABLE. Provider login email used."),
  invoice_id_last STRING OPTIONS(description="NULLABLE. Last known invoice id/ref."),
  contract_or_po STRING OPTIONS(description="NULLABLE. Contract or PO ref."),
  support_tier STRING OPTIONS(description="NULLABLE. standard/premium/etc."),
  renewal_notice_days INT64 OPTIONS(description="NULLABLE. Days before renewal to flag review."),
  provider_portal_url STRING OPTIONS(description="NULLABLE. Provider portal URL."),

  plan_features STRING OPTIONS(description="NULLABLE. Freeform features; use ' | ' separator."),
  plan_limits STRING OPTIONS(description="NULLABLE. Freeform limits; store ambiguous limits here."),
  limits_source_url STRING OPTIONS(description="NULLABLE. URL to docs/contract reference."),
  limits_last_verified_date DATE OPTIONS(description="NULLABLE. When limits were last checked."),

  notes STRING OPTIONS(description="NULLABLE. Internal notes.")
)
OPTIONS(description="Master subscription plans table (snake_case). Required fields enforced with NOT NULL.");


CREATE TABLE IF NOT EXISTS `your_project.your_dataset`.subscription_plan_costs_daily (
  provider STRING NOT NULL OPTIONS(description="REQUIRED. Provider key."),
  subscription_id STRING NOT NULL OPTIONS(description="REQUIRED. Subscription instance id."),
  plan_name STRING OPTIONS(description="NULLABLE. Plan identifier."),
  display_name STRING OPTIONS(description="NULLABLE. Friendly name."),

  cost_date DATE NOT NULL OPTIONS(description="REQUIRED. The day this cost applies to."),

  billing_cycle STRING OPTIONS(description="NULLABLE. monthly/annual."),
  currency STRING OPTIONS(description="NULLABLE. Currency for daily_cost."),

  seats INT64 NOT NULL OPTIONS(description="REQUIRED. Seats as of calculation snapshot."),
  quantity NUMERIC OPTIONS(description="NULLABLE. For cost-unification; typically equals seats."),
  unit STRING OPTIONS(description="NULLABLE. Unit of measure; for subscriptions typically 'seat'."),

  cycle_cost NUMERIC OPTIONS(description="NULLABLE. Net cost per billing cycle after discount."),
  daily_cost NUMERIC OPTIONS(description="NULLABLE. Prorated daily cost."),
  monthly_run_rate NUMERIC OPTIONS(description="NULLABLE. Derived monthly run-rate (daily_cost * days_in_month)."),
  annual_run_rate NUMERIC OPTIONS(description="NULLABLE. Derived annual run-rate (daily_cost * 365/366)."),

  invoice_id_last STRING OPTIONS(description="NULLABLE. Carried through from subscription_plans if available."),
  source STRING OPTIONS(description="NULLABLE. e.g., 'subscription_proration'"),
  updated_at TIMESTAMP OPTIONS(description="NULLABLE. Load timestamp.")
)
PARTITION BY cost_date
CLUSTER BY provider, subscription_id
OPTIONS(description="Daily subscription costs derived from subscription_plans. One row per subscription per day.");


-- Neutral name, but includes the full FOCUS v1.2 column set + internal fields.
CREATE TABLE IF NOT EXISTS `your_project.your_dataset`.cost_data_standard_1_2 (
  BillingAccountId STRING OPTIONS(description="Standard. Billing account identifier."),
  BillingAccountName STRING OPTIONS(description="Standard. Billing account name."),
  BillingAccountType STRING OPTIONS(description="Standard. Billing account type."),
  SubAccountId STRING OPTIONS(description="Standard. Sub-account identifier."),
  SubAccountName STRING OPTIONS(description="Standard. Sub-account name."),
  SubAccountType STRING OPTIONS(description="Standard. Sub-account type."),

  BilledCost NUMERIC OPTIONS(description="Standard. Billed cost amount."),
  BillingCurrency STRING OPTIONS(description="Standard. Currency for BilledCost."),
  ContractedCost NUMERIC OPTIONS(description="Standard. Contracted cost (if applicable)."),
  EffectiveCost NUMERIC OPTIONS(description="Standard. Effective cost (if applicable)."),
  ListCost NUMERIC OPTIONS(description="Standard. List cost (if applicable)."),
  ContractedUnitPrice NUMERIC OPTIONS(description="Standard. Contracted unit price (if applicable)."),
  EffectiveUnitPrice NUMERIC OPTIONS(description="Standard. Effective unit price (if applicable)."),
  ListUnitPrice NUMERIC OPTIONS(description="Standard. List unit price (if applicable)."),

  ConsumedQuantity NUMERIC OPTIONS(description="Standard. Consumed quantity."),
  ConsumedUnit STRING OPTIONS(description="Standard. Unit for consumed quantity."),

  CapacityReservationId STRING OPTIONS(description="Standard. Capacity reservation id."),
  CapacityReservationStatus STRING OPTIONS(description="Standard. Capacity reservation status."),
  CapacityReservation STRING OPTIONS(description="Standard. Capacity reservation label/name."),

  ChargeCategory STRING OPTIONS(description="Standard. Charge category."),
  ChargeClass STRING OPTIONS(description="Standard. Charge class."),
  ChargeDescription STRING OPTIONS(description="Standard. Charge description."),
  ChargeFrequency STRING OPTIONS(description="Standard. Charge frequency."),
  ChargeOrigination STRING OPTIONS(description="Standard. Charge origination."),

  InvoiceId STRING OPTIONS(description="Standard. Invoice identifier."),
  InvoiceIssuer STRING OPTIONS(description="Standard. Invoice issuer."),

  Provider STRING OPTIONS(description="Standard. Provider."),
  Publisher STRING OPTIONS(description="Standard. Publisher."),

  CommitmentDiscountCategory STRING OPTIONS(description="Standard. Commitment discount category."),
  CommitmentDiscountId STRING OPTIONS(description="Standard. Commitment discount id."),
  CommitmentDiscountName STRING OPTIONS(description="Standard. Commitment discount name."),
  CommitmentDiscountQuantity NUMERIC OPTIONS(description="Standard. Commitment discount quantity."),
  CommitmentDiscountStatus STRING OPTIONS(description="Standard. Commitment discount status."),
  CommitmentDiscountType STRING OPTIONS(description="Standard. Commitment discount type."),
  CommitmentDiscountUnit STRING OPTIONS(description="Standard. Commitment discount unit."),

  AvailabilityZone STRING OPTIONS(description="Standard. Availability zone."),
  RegionId STRING OPTIONS(description="Standard. Region id."),
  RegionName STRING OPTIONS(description="Standard. Region name."),

  PricingCategory STRING OPTIONS(description="Standard. Pricing category."),
  PricingCurrency STRING OPTIONS(description="Standard. Pricing currency."),
  PricingCurrencyContractedUnitPrice NUMERIC OPTIONS(description="Standard. Pricing-currency contracted unit price."),
  PricingCurrencyEffectiveCost NUMERIC OPTIONS(description="Standard. Pricing-currency effective cost."),
  PricingCurrencyListUnitPrice NUMERIC OPTIONS(description="Standard. Pricing-currency list unit price."),
  PricingQuantity NUMERIC OPTIONS(description="Standard. Pricing quantity."),
  PricingUnit STRING OPTIONS(description="Standard. Pricing unit."),

  ResourceId STRING OPTIONS(description="Standard. Resource id."),
  ResourceName STRING OPTIONS(description="Standard. Resource name."),
  ResourceType STRING OPTIONS(description="Standard. Resource type."),

  Tags STRING OPTIONS(description="Standard. Tags (string/serialized)."),

  ServiceCategory STRING OPTIONS(description="Standard. Service category."),
  ServiceName STRING OPTIONS(description="Standard. Service name."),
  ServiceSubcategory STRING OPTIONS(description="Standard. Service subcategory."),

  SkuId STRING OPTIONS(description="Standard. SKU id."),
  SkuMeter STRING OPTIONS(description="Standard. SKU meter."),
  SkuPriceDetails STRING OPTIONS(description="Standard. SKU price details."),
  SkuPriceId STRING OPTIONS(description="Standard. SKU price id."),

  BillingPeriodStart DATE OPTIONS(description="Standard. Billing period start."),
  BillingPeriodEnd DATE OPTIONS(description="Standard. Billing period end."),
  ChargePeriodStart DATE OPTIONS(description="Standard. Charge period start."),
  ChargePeriodEnd DATE OPTIONS(description="Standard. Charge period end."),

  SourceSystem STRING OPTIONS(description="INTERNAL. Producer of this row (e.g., subscription_costs_daily)."),
  SourceRecordId STRING OPTIONS(description="INTERNAL. Source record id (e.g., subscription_id)."),
  UpdatedAt TIMESTAMP OPTIONS(description="INTERNAL. Load timestamp.")
)
PARTITION BY ChargePeriodStart
CLUSTER BY Provider, ServiceName, SkuId, InvoiceId
OPTIONS(description="Neutral standardized costs table using the complete FOCUS v1.2 column set + internal fields.");
