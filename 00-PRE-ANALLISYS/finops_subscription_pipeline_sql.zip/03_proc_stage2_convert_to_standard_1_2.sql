-- Procedure: sp_convert_subscription_costs_daily_to_standard_1_2
-- Stage 2: Map subscription daily costs into the standardized cost table (complete FOCUS v1.2 column set).
CREATE OR REPLACE PROCEDURE `your_project.your_dataset`.sp_convert_subscription_costs_daily_to_standard_1_2(
  p_start_date DATE,
  p_end_date DATE
)
BEGIN
  ASSERT p_start_date IS NOT NULL AS "p_start_date cannot be NULL";
  ASSERT p_end_date IS NOT NULL AS "p_end_date cannot be NULL";
  ASSERT p_end_date >= p_start_date AS "p_end_date must be >= p_start_date";

  -- Rebuild window for this source to avoid stale future rows
  DELETE FROM `your_project.your_dataset`.cost_data_standard_1_2
  WHERE ChargePeriodStart BETWEEN p_start_date AND p_end_date
    AND SourceSystem = 'subscription_costs_daily';

  INSERT INTO `your_project.your_dataset`.cost_data_standard_1_2 (
    BillingAccountId, BillingAccountName, BillingAccountType,
    SubAccountId, SubAccountName, SubAccountType,

    BilledCost, BillingCurrency,
    ContractedCost, EffectiveCost, ListCost,
    ContractedUnitPrice, EffectiveUnitPrice, ListUnitPrice,

    ConsumedQuantity, ConsumedUnit,

    CapacityReservationId, CapacityReservationStatus, CapacityReservation,

    ChargeCategory, ChargeClass, ChargeDescription, ChargeFrequency, ChargeOrigination,

    InvoiceId, InvoiceIssuer,

    Provider, Publisher,

    CommitmentDiscountCategory, CommitmentDiscountId, CommitmentDiscountName,
    CommitmentDiscountQuantity, CommitmentDiscountStatus, CommitmentDiscountType, CommitmentDiscountUnit,

    AvailabilityZone, RegionId, RegionName,

    PricingCategory, PricingCurrency,
    PricingCurrencyContractedUnitPrice, PricingCurrencyEffectiveCost, PricingCurrencyListUnitPrice,
    PricingQuantity, PricingUnit,

    ResourceId, ResourceName, ResourceType,

    Tags,

    ServiceCategory, ServiceName, ServiceSubcategory,

    SkuId, SkuMeter, SkuPriceDetails, SkuPriceId,

    BillingPeriodStart, BillingPeriodEnd, ChargePeriodStart, ChargePeriodEnd,

    SourceSystem, SourceRecordId, UpdatedAt
  )
  SELECT
    -- Account (usually unknown for SaaS subscription proration)
    NULL, NULL, NULL,
    NULL, NULL, NULL,

    -- Cost/currency
    spc.daily_cost AS BilledCost,
    spc.currency AS BillingCurrency,

    -- Cost variants not computed here
    NULL, NULL, NULL,
    NULL, NULL, NULL,

    -- Quantity modeled as "seats"
    spc.quantity AS ConsumedQuantity,
    spc.unit AS ConsumedUnit,

    -- Cloud-only
    NULL, NULL, NULL,

    -- Charge classification
    'Subscription' AS ChargeCategory,
    'Recurring' AS ChargeClass,
    CONCAT('Subscription daily proration: ', spc.display_name, ' / ', spc.plan_name) AS ChargeDescription,
    CASE
      WHEN spc.billing_cycle IN ('annual','yearly','year') THEN 'Annual'
      WHEN spc.billing_cycle IN ('monthly','month') THEN 'Monthly'
      ELSE NULL
    END AS ChargeFrequency,
    'Calculated' AS ChargeOrigination,

    -- Invoice best-effort
    spc.invoice_id_last AS InvoiceId,
    NULL AS InvoiceIssuer,

    -- Provider/Publisher
    spc.provider AS Provider,
    NULL AS Publisher,

    -- Commitment discounts
    NULL, NULL, NULL,
    NULL, NULL, NULL, NULL,

    -- Location
    NULL, NULL, NULL,

    -- Pricing
    NULL, NULL,
    NULL, NULL, NULL,
    NULL, NULL,

    -- Resource
    NULL, NULL, NULL,

    -- Tags
    NULL,

    -- Service
    'SaaS' AS ServiceCategory,
    spc.display_name AS ServiceName,
    NULL AS ServiceSubcategory,

    -- SKU
    spc.plan_name AS SkuId,
    NULL AS SkuMeter,
    NULL AS SkuPriceDetails,
    NULL AS SkuPriceId,

    -- Periods
    DATE_TRUNC(spc.cost_date, MONTH) AS BillingPeriodStart,
    DATE_SUB(DATE_ADD(DATE_TRUNC(spc.cost_date, MONTH), INTERVAL 1 MONTH), INTERVAL 1 DAY) AS BillingPeriodEnd,
    spc.cost_date AS ChargePeriodStart,
    spc.cost_date AS ChargePeriodEnd,

    -- Internal
    'subscription_costs_daily' AS SourceSystem,
    spc.subscription_id AS SourceRecordId,
    CURRENT_TIMESTAMP() AS UpdatedAt
  FROM `your_project.your_dataset`.subscription_plan_costs_daily spc
  WHERE spc.cost_date BETWEEN p_start_date AND p_end_date;
END;
