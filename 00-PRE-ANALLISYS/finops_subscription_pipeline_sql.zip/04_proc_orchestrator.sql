-- Procedure: sp_run_subscription_costs_pipeline
-- Runs Stage 1 (daily cost calc) then Stage 2 (standardized table load).
CREATE OR REPLACE PROCEDURE `your_project.your_dataset`.sp_run_subscription_costs_pipeline(
  p_start_date DATE,
  p_end_date DATE
)
BEGIN
  CALL `your_project.your_dataset`.sp_calculate_subscription_plan_costs_daily(p_start_date, p_end_date);
  CALL `your_project.your_dataset`.sp_convert_subscription_costs_daily_to_standard_1_2(p_start_date, p_end_date);
END;
