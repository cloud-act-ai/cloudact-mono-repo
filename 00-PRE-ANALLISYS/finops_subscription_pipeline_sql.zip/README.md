# FinOps Subscription → Daily Costs → Standardized Cost Table (v1.2 column set)

This bundle creates:
- `subscription_plans` (master)
- `subscription_plan_costs_daily` (derived daily costs)
- `cost_data_standard_1_2` (neutral standardized costs table with the complete v1.2 column set + internal fields)

## Stage flow diagram

Stage 0: Inputs
  - Table: subscription_plans
  - Required: provider, plan_name, display_name, subscription_id, seats

Stage 1: Daily costs (procedure)
  Procedure: sp_calculate_subscription_plan_costs_daily(start_date, end_date)
  Step 1: Validate inputs (ASSERTs)
  Step 2: Delete existing derived rows in window (prevents stale future rows after cancel)
  Step 3: Generate date spine (one row per day)
  Step 4: Determine cycle_price
          - prefer price_per_cycle
          - else fallback to unit_price_usd/yearly_price_usd based on billing_cycle/billing_period
  Step 5: Apply discount (percent/fixed)
  Step 6: Prorate to daily_cost
          - monthly: cycle_cost / days_in_month
          - annual:  cycle_cost / 365 or 366 (leap-year safe)
  Step 7: Derive run rates
          - monthly_run_rate = daily_cost * days_in_month
          - annual_run_rate  = daily_cost * days_in_year
  Output: subscription_plan_costs_daily

Stage 2: Standardized table load (procedure)
  Procedure: sp_convert_subscription_costs_daily_to_standard_1_2(start_date, end_date)
  Step 1: Delete existing standardized rows for SourceSystem='subscription_costs_daily' in window
  Step 2: Insert mapped rows
          - populate applicable columns (BilledCost, BillingCurrency, Provider, ServiceName, etc.)
          - leave non-applicable columns NULL (but present)

Stage 3: Orchestrator
  Procedure: sp_run_subscription_costs_pipeline(start_date, end_date)
  Calls Stage 1 then Stage 2.

## How to run (example)
Daily (yesterday):
```sql
CALL `your_project.your_dataset`.sp_run_subscription_costs_pipeline(
  DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY),
  DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)
);
```

Backfill a month:
```sql
CALL `your_project.your_dataset`.sp_run_subscription_costs_pipeline(DATE('2025-12-01'), DATE('2025-12-31'));
```

## Notes on "constraints"
BigQuery does not support CHECK constraints like Postgres.
We enforce required fields using:
- NOT NULL columns in `subscription_plans`
- ASSERT guardrails inside procedures
