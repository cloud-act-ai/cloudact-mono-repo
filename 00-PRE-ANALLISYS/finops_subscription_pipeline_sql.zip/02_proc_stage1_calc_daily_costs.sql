-- Procedure: sp_calculate_subscription_plan_costs_daily
-- Stage 1: Expand subscription plans into daily cost rows (cancellation-safe).
CREATE OR REPLACE PROCEDURE `your_project.your_dataset`.sp_calculate_subscription_plan_costs_daily(
  p_start_date DATE,
  p_end_date DATE
)
BEGIN
  -- Guardrails
  ASSERT p_start_date IS NOT NULL AS "p_start_date cannot be NULL";
  ASSERT p_end_date IS NOT NULL AS "p_end_date cannot be NULL";
  ASSERT p_end_date >= p_start_date AS "p_end_date must be >= p_start_date";

  -- Validate minimum viable data exists
  ASSERT (
    SELECT COUNT(1)
    FROM `your_project.your_dataset`.subscription_plans
    WHERE provider IS NOT NULL
      AND plan_name IS NOT NULL
      AND display_name IS NOT NULL
      AND subscription_id IS NOT NULL
      AND seats IS NOT NULL
  ) > 0 AS "subscription_plans has no valid rows (required fields missing)";

  -- Rebuild the requested window to prevent stale future rows after cancellations
  DELETE FROM `your_project.your_dataset`.subscription_plan_costs_daily
  WHERE cost_date BETWEEN p_start_date AND p_end_date;

  CREATE TEMP TABLE date_spine AS
  SELECT d AS cost_date
  FROM UNNEST(GENERATE_DATE_ARRAY(p_start_date, p_end_date)) AS d;

  INSERT INTO `your_project.your_dataset`.subscription_plan_costs_daily (
    provider, subscription_id, plan_name, display_name,
    cost_date, billing_cycle, currency,
    seats, quantity, unit,
    cycle_cost, daily_cost, monthly_run_rate, annual_run_rate,
    invoice_id_last, source, updated_at
  )
  WITH base AS (
    SELECT
      sp.provider,
      sp.subscription_id,
      sp.plan_name,
      sp.display_name,
      LOWER(COALESCE(sp.billing_cycle, sp.billing_period)) AS billing_cycle,
      COALESCE(sp.currency, 'USD') AS currency,
      CAST(sp.seats AS INT64) AS seats,
      COALESCE(
        sp.price_per_cycle,
        CASE
          WHEN LOWER(COALESCE(sp.billing_cycle, sp.billing_period)) IN ('monthly','month') THEN sp.unit_price_usd
          WHEN LOWER(COALESCE(sp.billing_cycle, sp.billing_period)) IN ('annual','yearly','year') THEN sp.yearly_price_usd
          ELSE NULL
        END
      ) AS cycle_price,
      sp.discount_type,
      sp.discount_value,
      sp.start_date,
      sp.end_date,
      sp.cancellation_date,
      sp.invoice_id_last
    FROM `your_project.your_dataset`.subscription_plans sp
  ),
  priced AS (
    SELECT
      *,
      CASE
        WHEN cycle_price IS NULL THEN NULL
        WHEN LOWER(discount_type) = 'percent' AND discount_value IS NOT NULL THEN cycle_price * (1 - discount_value / 100)
        WHEN LOWER(discount_type) = 'fixed'   AND discount_value IS NOT NULL THEN cycle_price - discount_value
        ELSE cycle_price
      END AS cycle_cost
    FROM base
  ),
  expanded AS (
    SELECT
      p.provider,
      p.subscription_id,
      p.plan_name,
      p.display_name,
      ds.cost_date,
      p.billing_cycle,
      p.currency,
      p.seats,
      CAST(p.seats AS NUMERIC) AS quantity,
      'seat' AS unit,
      p.cycle_cost,
      CASE
        WHEN p.cycle_cost IS NULL THEN NULL
        WHEN p.billing_cycle IN ('monthly','month')
          THEN p.cycle_cost / EXTRACT(DAY FROM LAST_DAY(ds.cost_date))
        WHEN p.billing_cycle IN ('annual','yearly','year')
          THEN p.cycle_cost / (
            CASE
              WHEN MOD(EXTRACT(YEAR FROM ds.cost_date), 400) = 0 THEN 366
              WHEN MOD(EXTRACT(YEAR FROM ds.cost_date), 100) = 0 THEN 365
              WHEN MOD(EXTRACT(YEAR FROM ds.cost_date), 4) = 0 THEN 366
              ELSE 365
            END
          )
        ELSE NULL
      END AS daily_cost,
      p.invoice_id_last
    FROM priced p
    JOIN date_spine ds ON TRUE
    WHERE
      (p.start_date IS NULL OR ds.cost_date >= p.start_date)
      AND (p.end_date IS NULL OR ds.cost_date <= p.end_date)
      AND (p.cancellation_date IS NULL OR ds.cost_date <= p.cancellation_date)
  )
  SELECT
    provider, subscription_id, plan_name, display_name,
    cost_date, billing_cycle, currency,
    seats, quantity, unit,
    cycle_cost,
    daily_cost,
    CASE WHEN daily_cost IS NULL THEN NULL ELSE daily_cost * EXTRACT(DAY FROM LAST_DAY(cost_date)) END AS monthly_run_rate,
    CASE
      WHEN daily_cost IS NULL THEN NULL
      ELSE daily_cost * (
        CASE
          WHEN MOD(EXTRACT(YEAR FROM cost_date), 400) = 0 THEN 366
          WHEN MOD(EXTRACT(YEAR FROM cost_date), 100) = 0 THEN 365
          WHEN MOD(EXTRACT(YEAR FROM cost_date), 4) = 0 THEN 366
          ELSE 365
        END
      )
    END AS annual_run_rate,
    invoice_id_last,
    'subscription_proration' AS source,
    CURRENT_TIMESTAMP() AS updated_at
  FROM expanded;
END;
